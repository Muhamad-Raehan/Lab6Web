# Berdasarkan gambar layout web berikut, buatlah menggunakan Twitter Bootstrap
![foto](foto/bts.png)